module.exports.execute = () => {
    process.exit(0);
}