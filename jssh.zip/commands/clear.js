module.exports.execute = async () => {
    console.clear();
}

module.exports.description = 
`Clears console.`