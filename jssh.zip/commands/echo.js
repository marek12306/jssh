module.exports.execute = async (cwd, args) => {
    console.log(args.join(" "))
}

module.exports.description = 
`Displays text.`;