module.exports.execute = async () => {};

module.exports.description = 
`This command does nothing. Used for comments in scripts.`;