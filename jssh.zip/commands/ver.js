module.exports.execute = (cwd, args, dirs, cd, ver) => {
    console.log("JSSH version "+ver);
}

module.exports.description = 
`Displays current version of JSSH`;